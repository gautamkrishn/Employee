package com.capgemini.bean;

public class EmployeeBean {

	private String empNo;
	private String empName;
	public String getEmpNo() {
		return empNo;
	}
	public void setEmpNo(String empNo) {
		this.empNo = empNo;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	@Override
	public String toString() {
		return "EmployeeBean [empNo=" + empNo + ", empName=" + empName + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
