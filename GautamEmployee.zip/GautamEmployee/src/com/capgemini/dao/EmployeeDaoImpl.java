
	
	package com.capgemini.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bean.EmployeeBean;
import com.capgemini.exception.EmployeeException;
import com.capgemini.util.DBConnection;








public class EmployeeDaoImpl implements IEmployeeDAO 
{
	
	Logger logger=Logger.getRootLogger();
	public EmployeeDaoImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	

	//------------------------ 1. Employee Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	addEmployeeDetails(EmployeeBean employee)
	 - Input Parameters	:	EmployeeBean employee
	 - Return Type		:	String
	 - Throws			:  	EmployeeException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	03/11/2018
	 - Description		:	Adding Employee
	 ********************************************************************************************************/

	
	public String addEmployeeDetails(EmployeeBean employee) throws EmployeeException 
	{
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String employeeNo=null;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

					
			preparedStatement.setString(1,employee.getEmpName());
					
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.EMPLOYEE_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				employeeNo=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new EmployeeException("Inserting employee details failed ");

			}
			else
			{
				logger.info("Employee details added successfully:");
				return employeeNo;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new EmployeeException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new EmployeeException("Error in closing db connection");

			}
		}
		
		
	}

	//------------------------ 1. Employee Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	viewEmployeeDetails(String employeeId)
	 - Input Parameters	:	employeeId
	 - Return Type		:	EmployeeBean
	 - Throws			:  	EmployeeException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	03/11/2018
	 - Description		:	ViewEmployeeDetails
	 ********************************************************************************************************/
	public EmployeeBean viewEmployeeDetails(String employeeNo) throws EmployeeException {
		
		Connection connection=DBConnection.getInstance().getConnection();
		
		
		PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
		EmployeeBean bean=null;
		
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper.VIEW_EMPLOYEE_DETAILS_QUERY);
			preparedStatement.setString(1,employeeNo);
			resultset=preparedStatement.executeQuery();
			
			if(resultset.next())
			{
				bean = new EmployeeBean();
				bean.setEmpNo(resultset.getString(1));
				bean.setEmpName(resultset.getString(2));
				
			}
			
			if( bean != null)
			{
				logger.info("Record Found Successfully");
				return bean;
			}
			else
			{
				logger.info("Record Not Found Successfully");
				return null;
			}
			
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
			throw new EmployeeException(e.getMessage());
		}
		finally
		{
			try 
			{
				resultset.close();
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new EmployeeException("Error in closing db connection");

			}
		}
		
	}

	//------------------------ 1. Employee Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	retriveAllDetails()
	 - Input Parameters	:	
	 - Return Type		:	List
	 - Throws		    :  	EmployeeException
	 - Author	     	:	CAPGEMINI
	 - Creation Date	:	03/11/2018
	 - Description		:	return list
	 ********************************************************************************************************/

	public List<EmployeeBean> retriveAllDetails() throws EmployeeException {
		
		Connection con=DBConnection.getInstance().getConnection();
		int employeeCount = 0;
		
		PreparedStatement ps=null;
		ResultSet resultset = null;
		
		List<EmployeeBean> employeeList=new ArrayList<EmployeeBean>();
		try
		{
			ps=con.prepareStatement(QueryMapper.RETRIVE_ALL_QUERY);
			resultset=ps.executeQuery();
			
			while(resultset.next())
			{	
				EmployeeBean bean=new EmployeeBean();
				bean.setEmpName(resultset.getString(1));
				bean.setEmpNo(resultset.getString(2));
				
				employeeList.add(bean);
				
				employeeCount++;
			}			
			
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new EmployeeException("Tehnical problem occured. Refer log");
		}
		
		finally
		{
			try 
			{
				resultset.close();
				ps.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new EmployeeException("Error in closing db connection");

			}
		}
		
		if( employeeCount == 0)
			return null;
		else
			return employeeList;
	}

}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
