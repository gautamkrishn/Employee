package com.capgemini.dao;

import java.util.List;

import com.capgemini.bean.EmployeeBean;
import com.capgemini.exception.EmployeeException;

public interface IEmployeeDAO {

	
	
	public String addEmployeeDetails(EmployeeBean employee) throws EmployeeException;
	public EmployeeBean viewEmployeeDetails(String employeeNo) throws EmployeeException;
	public List<EmployeeBean> retriveAllDetails()throws EmployeeException;
	
	
	
	
	
	
	
	
}
