package com.capgemini.dao;

public interface QueryMapper {

	
	
	public static final String RETRIVE_ALL_QUERY="SELECT employee_no, employee_name FROM employee_details";
	public static final String VIEW_EMPLOYEE_DETAILS_QUERY="SELECT employee_no, employee_name FROM employee_details WHERE  employee_no=?";
	public static final String INSERT_QUERY="INSERT INTO employee_details VALUES(employee_no_sequence.NEXTVAL,?)";
	public static final String EMPLOYEE_QUERY_SEQUENCE="SELECT employee_no_sequence.CURRVAL FROM DUAL";
	
	
	
	
	
	
	
}
