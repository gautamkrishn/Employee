package com.capgemini.exception;

public class EmployeeException extends Exception {
	
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7831258812670875939L;

	public EmployeeException(String message)
	{
		super(message);
	}
	
	
	
	
	
	

}
