package com.capgemini.pi;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bean.EmployeeBean;
import com.capgemini.exception.EmployeeException;
import com.capgemini.service.IEmployeeService;
import com.capgemini.service.EmployeeServiceImpl;



public class EmployeeMain {

	static Scanner sc = new Scanner(System.in);
	static com.capgemini.service.IEmployeeService employeeService = null;
	static EmployeeServiceImpl employeeServiceImpl = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) {
		PropertyConfigurator.configure("resources//log4j.properties");
		EmployeeBean employeeBean = null;

		String employeeId = null;
		int option = 0;

		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("   ICARE CAPGEMINI TRUST ");
			System.out.println("_______________________________\n");

			System.out.println("1.Add Employee ");
			System.out.println("2.View Employee");
			System.out.println("3.Retrive All");
			System.out.println("4.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {

				case 1:

					while (employeeBean == null) {
						employeeBean = populateEmployeeBean();
						// System.out.println(employeeBean);
					}

					try {
						employeeService = new EmployeeServiceImpl();
						employeeId = employeeService.addEmployeeDetails(employeeBean);

						System.out
								.println("Employee details  has been successfully registered ");
						System.out.println("Employee  ID Is: " + employeeId);

					} catch (EmployeeException employeeException) {
						logger.error("exception occured", employeeException);
						System.out.println("ERROR : "
								+ employeeException.getMessage());
					} finally {
						employeeId = null;
						employeeService = null;
						employeeBean = null;
					}

					break;

				case 2:

					employeeServiceImpl = new EmployeeServiceImpl();

					System.out.println("Enter numeric employee id:");
					employeeId = sc.next();

					while (true) {
						if (employeeServiceImpl.validateEmployeeId(employeeId)) {
							break;
						} else {
							System.err
									.println("Please enter numeric employee id only, try again");
							employeeId = sc.next();
						}
					}

					employeeBean = getEmployeeDetails(employeeId);

					if (employeeBean != null) {
						System.out.println("Employee No  "		+ employeeBean.getEmpNo());
						System.out.println("Employee name          :"
								+ employeeBean.getEmpName());
					
					} else {
						System.err
								.println("There is no Employee details associated with employee id "
										+ employeeId);
					}

					break;

				case 3:

					employeeService = new EmployeeServiceImpl();
					try {
						List<EmployeeBean> employeeList = new ArrayList<EmployeeBean>();
						employeeList = employeeService.retriveAll();

						if (employeeList != null) {
							Iterator<EmployeeBean> i = employeeList.iterator();
							while (i.hasNext()) {
								System.out.println(i.next());
							}
						} else {
							System.out
									.println("No Employee , yet.");
						}

					}

					catch (EmployeeException e) {

						System.out.println("Error  :" + e.getMessage());
					}

					break;

				case 4:

					System.out.print("Exit  Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-4]");
				}// end of switch
			}

			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}

		}// end of while
	}// end of try

	/*
	 * This function will call the service layer method and return the bean
	 * object which is populated by the information of the given employeeId in
	 * parameter
	 */
	private static EmployeeBean getEmployeeDetails(String employeeId) {
		EmployeeBean employeeBean = null;
		employeeService = new EmployeeServiceImpl();

		try {
			employeeBean = employeeService.viewEmployeeDetails(employeeId);
		} catch (EmployeeException donarException) {
			logger.error("exception occured ", donarException);
			System.out.println("ERROR : " + donarException.getMessage());
		}

		employeeService = null;
		return employeeBean;
	}

	/*
	 * This function will be called by main and will return a validated bean
	 * object OR null if details are invalid
	 */
	private static EmployeeBean populateEmployeeBean() {

		// Reading and setting the values for the employeeBean
		
		EmployeeBean employeeBean = new EmployeeBean();;

		System.out.println("\n Enter Details");

		System.out.println("Enter employee name: ");
		employeeBean.setEmpName(sc.next());

	

	

		employeeServiceImpl = new EmployeeServiceImpl();

		try {
			employeeServiceImpl.validateEmployee(employeeBean);
			return employeeBean;
		} catch (EmployeeException employeeException) {
			logger.error("exception occured", employeeException);
			System.err.println("Invalid data:");
			System.err.println(employeeException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return null;

	}
}
