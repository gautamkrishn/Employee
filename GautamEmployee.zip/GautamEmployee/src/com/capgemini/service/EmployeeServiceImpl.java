package com.capgemini.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bean.EmployeeBean;
import com.capgemini.dao.EmployeeDaoImpl;
import com.capgemini.dao.IEmployeeDAO;
import com.capgemini.exception.EmployeeException;



public class EmployeeServiceImpl implements IEmployeeService {

	
IEmployeeDAO employeeDao;
	
	//------------------------ 1. Employee Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	addEmployeeDetails
	 - Input Parameters	:	employee object
	 - Return Type		:	String id
	 - Throws			:  	EmployeeException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	03/11/2018
	 - Description		:	adding employee to database calls dao method addEmployeeDetails(employee)
	 ********************************************************************************************************/
	public String addEmployeeDetails(EmployeeBean employee) throws EmployeeException {
		employeeDao=new EmployeeDaoImpl();	
		String employeeSeq;
		employeeSeq= employeeDao.addEmployeeDetails(employee);
		return employeeSeq; 
	}

	//------------------------ 1. Employee Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	viewEmployeeDetails
	 - Input Parameters	:	String employeeNo
	 - Return Type		:	employee object
	 - Throws		    :  	EmployeeException
	 - Author		    :	CAPGEMINI
	 - Creation Date	:	03/11/2018
	 - Description		:	calls dao method viewEmployeeDetails(employeeNo)
	 ********************************************************************************************************/
	public EmployeeBean viewEmployeeDetails(String employeeNo) throws EmployeeException {
		employeeDao=new EmployeeDaoImpl();
		EmployeeBean bean=null;
		bean=employeeDao.viewEmployeeDetails(employeeNo);
		return bean;
	}

	//------------------------ 1. Employee Application --------------------------
	/*******************************************************************************************************
	 - Function Name	: retriveAll()
	 - Input Parameters	:	
	 - Return Type		: list
	 - Throws		    : EmployeeException
	 - Author	      	: CAPGEMINI 
	 - Creation Date	: 03/11/2018
	 - Description		: calls dao method retriveAllDetails()
	 ********************************************************************************************************/
	public List<EmployeeBean> retriveAll() throws EmployeeException {
		employeeDao=new EmployeeDaoImpl();
		List<EmployeeBean> employeeList=null;
		employeeList=employeeDao.retriveAllDetails();
		return employeeList;
	}
	
	
	/*******************************************************************************************************
	 - Function Name	: validateEmployee(EmployeeBean bean)
	 - Input Parameters	: EmployeeBean bean
	 - Return Type		: void
	 - Throws		    : EmployeeException
	 - Author	      	: CAPGEMINI
	 - Creation Date	: 03/11/2018
	 - Description		: validates the EmployeeBean object
	 ********************************************************************************************************/
	public void validateEmployee(EmployeeBean bean) throws EmployeeException
	{
		List<String> validationErrors = new ArrayList<String>();

		//Validating employee name
		if(!(isValidName(bean.getEmpName()))) {
			validationErrors.add("\n Donar Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
	
		
		if(!validationErrors.isEmpty())
			throw new EmployeeException(validationErrors +"");
	}

	public boolean isValidName(String employeeName){
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(employeeName);
		return nameMatcher.matches();
	}
	public boolean isValidAddress(String address){
		return (address.length() > 6);
	}
	
	public boolean isValidPhoneNumber(String phoneNumber){
		Pattern phonePattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(phoneNumber);
		return phoneMatcher.matches();
		
	}
	public boolean isValidAmount(double amount){
		return (amount>0);
	}
	public boolean validateEmployeeId(String employeeNo) {
		
		Pattern idPattern = Pattern.compile("[0-9]{1,4}");
		Matcher idMatcher = idPattern.matcher(employeeNo);
		
		if(idMatcher.matches())
			return true;
		else
			return false;		
	}
	
	
	
	
	
	
	
	
}
