package com.capgemini.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.bean.EmployeeBean;
import com.capgemini.dao.EmployeeDaoImpl;
import com.capgemini.exception.EmployeeException;

public class EmployeeDaoTest {

	
	static EmployeeDaoImpl dao;
	static EmployeeBean employee;

	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new EmployeeDaoImpl();
		employee = new EmployeeBean();
	}

	@Test
	public void testAddDonarDetails() throws EmployeeException {

		assertNotNull(dao.addEmployeeDetails(employee));

	}

	/************************************
	 * Test case for addDonarDetails()
	 * 
	 ************************************/

	@Ignore
	@Test
	public void testAddDonarDetails1() throws EmployeeException {
		// increment the number next time you test for positive test case
		assertEquals(1001, dao.addEmployeeDetails(employee));
	}

	/************************************
	 * Test case for addDonarDetails()
	 * 
	 ************************************/

	@Test
	public void testAddDonarDetails2() throws EmployeeException {

		employee.setEmpName("Shashwathi");
		employee.setEmpNo("987");
		
		assertTrue("Data Inserted successfully",
				Integer.parseInt(dao.addEmployeeDetails(employee)) > 1000);

	}

	/********************************************
	 * Test case for retriveAllDetails()
	 ************************************************/
	@Test
	public void testViewAll() throws EmployeeException {
		assertNotNull(dao.retriveAllDetails());
	}

	/****************************************************
	 * Test case for viewById()
	 ******************************************************/

	

	
	
	
	
	
	
	

}
